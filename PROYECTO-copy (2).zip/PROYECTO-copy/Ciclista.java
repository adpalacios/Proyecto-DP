
import java.util.*;
/**
 * Write a description of class Ciclista here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Ciclista
{
    // instance variables - replace the example below with your own
   private String nombre;
   private Bicicleta bici;
   private double habilidad;
   private double energia;
   private Map<Etapa,Double> resultados;
   private Equipo equipo;

    /**
     * Constructor for objects of class Ciclista
     */
    public Ciclista(String nombre,Bicicleta bici,double habilidad,double energia,Equipo equipo)
    {
        // initialise instance variables
        this.nombre=nombre;
        this.bici=bici;
        this.habilidad=habilidad;
        this.energia=energia;
        this.resultados = new HashMap<>();
        this.equipo=equipo;
    }
     public String getNombre(){
         return this.nombre;
     }
     public void setNombre(String nombre){
         this.nombre=nombre;
     }
     public Bicicleta getBici(){
         return this.bici;
     }
     public void setBici(Bicicleta bici){
         this.bici=bici;
     }
     public double getHabilidad(){
         return this.habilidad;
     }
     public void setHabilidad(double habilidad){
            this.habilidad=habilidad;
            
     }
     public double getEnergia(){
         return this.energia;
     }
     public void setEnergia(double energia){
         this.energia=energia;
     }
     public Map<Etapa,Double> getResultados(){
         return this.resultados;
     }
     public void setResultados(Map<Etapa,Double> resultados){
         this.resultados=resultados;
     }
     public Equipo getEquipo(){
         return this.equipo;
     }
     public void setEquipo(Equipo equipo){
         this.equipo=equipo;
     }
    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public boolean abandono(double tiempoMin,double energia)
    {
        boolean abandonar=false;
        // put your code here
        if(tiempoMin<energia){
            System.out.println("El competidor no ha abandonado.");
        }else{
            abandonar=true;
            System.out.println("El competidor ha abandonado.");
        }
        
    return abandonar;
   }
   public void mostrarResultado(Etapa etapa){
       if(resultados.containsKey(etapa)){
           etapa.mostrarEtapa();
           System.out.println("El tiempo es:"+resultados.get(etapa));
       }
   }
   public void mostrarInformacionCarrera(Organizacion org){
       ArrayList<Etapa> lista= org.getEtapas();
       int cont=0;
       for(Etapa et:lista){
           cont++;
       }
       
    }
}

