
/**
 * Write a description of class Bicicleta here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bicicleta
{
    // instance variables - replace the example below with your own
    private String nombre;
    private double peso;
    

    /**
     * Constructor for objects of class Bicicleta
     */
    public Bicicleta(String nombre,double peso)
    {
        // initialise instance variables
        this.nombre=nombre;
        this.peso=peso;
    }
    public String getNombre(){
        return this.nombre;
    }
    public void setNombre(String nombre){
        this.nombre=nombre;
    }
    public double getPeso(){
        return this.peso;
    }
    public void setPeso(double peso){
        this.peso=peso;
    }
    
    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public double calcularVelocidad(double habilidad,double peso,double dificultad)
    {
     double velocidad;
     
     velocidad=(habilidad*100)/(peso*dificultad);
     
     return velocidad;
    }
    public double tiempoMinutos(int distancia, double velocidad){
        
     double tiempoMin = (distancia/velocidad)*60;
     
     return tiempoMin;
    }
}
