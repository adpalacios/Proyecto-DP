
/**
 * Write a description of class Etapa here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Etapa
{
    private String nombre;
    private double dificultad;
    private int distancia;// instance variables - replace the example below with your own

    /**
     * Constructor for objects of class Etapa
     */
    public Etapa(String nombre,double dificultad,int distancia)
    {
        // initialise instance variables
        this.nombre=nombre;
        this.dificultad=dificultad;
        this.distancia=distancia;
    }
    public String getNombre(){
        return this.nombre;
    }
    public void setNombre(String nombre){
        this.nombre=nombre;
    }
    public double getDificultad(){
        return this.dificultad;
    }
    public void setDificultad(double dificultad){
        this.dificultad=dificultad;
    }
    public int getDistancia(){
      return this.distancia;  
    }
    public void setDistancia(int distancia){
        this.distancia=distancia;
    }
    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public void mostrarEtapa()
    {
        System.out.println("El nombre de la Etapa es: "+this.nombre);
        System.out.println("La dificultad de la Etapa es: "+this.dificultad);
        System.out.println("La distancia de la Etapa es: "+this.distancia);
        System.out.println();
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
